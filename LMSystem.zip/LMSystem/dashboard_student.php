<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php 

if(isset($_POST['dash_submit']))
{
        $id=$_POST['dash_ID'];
		$name_input=$_POST['dash_name'];
		$year_input=$_POST['dash_year'];
		$course_input=$_POST['dash_course'];

		$sql = "INSERT INTO student (sID,sName,sYear,sCourse)
        VALUES('$id','$name_input','$year_input','$course_input')";
        mysqli_query($link,$sql) or die (mysqli_error());
            

           
                            echo '<script type="text/javascript">';
							echo 'alert("Successful Added! \n WELCOME ");';
							echo '</script>';

}


?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="">
<center>
            <form action="" method="POST" style="margin-top:-20%;">
           
            <div class="inputs">
            <div class="text">
                
            </div>  
            <div class="user">
                <div id="user">
                        <input type="text1" name="dash_ID" required value="" placeholder="Enter Student ID">
                </div> 
            </div>
            <div class="user">
                <div id="user">
                        <input type="text1" name="dash_name" required value="" placeholder="Enter Student Name">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_year" required value="" placeholder="Year in Number">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_course" required value="" placeholder="Course Taken">
                </div> 
            </div>
            <div class="button-con">    
                    <input type="submit" name="dash_submit" class="bttn">
            </div>
            </div>
            </form>  
</center>    

			<div class="fetch-user">
			<center class="ce">
				<table>
					 <?php

						session_start();
						include("config.php");

                         echo   "<tr>
                                  <th>Student ID</th><br>
		                          <th>Student Name</th><br>
		                          <th>Year Level</th>
		                          <th>Course Taken</th>
		                          <th colspan='2'>Action</th>
		                		</tr>";

		                 $sql = mysqli_query($link, "SELECT * FROM student ");
		                          while($res=mysqli_fetch_array($sql)){
		                          echo "<td>$res[sID]</td>";
		                          echo "<td>$res[sName]</td>";
		                          echo "<td>$res[sYear]</td>";
		                          echo "<td>$res[sCourse]</td>";

		                          echo "<td>&nbsp<button style='border: 1px solid red;background-color:#f2f2f2;font-family: arial;'><a href='student_updates.php?id=$res[sID]' 
		                          style='color:black;text-decoration: none;' \> Update </a></button></td>";
		                          echo "<td>&nbsp<button style='border: 1px solid red;background-color:#f2f2f2;font-family: arial;'><a href='student_deletes.php?id=$res[sID]' 
		                          style='color:black;text-decoration: none;' \">Delete</a></button></td>";

		                          echo "</tr>";
		                          }
		                    ?>
            	</table>
        	</center>

			</div>
</body>
</html>