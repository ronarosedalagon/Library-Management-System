<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>

<!DOCTYPE html>
<html>
    <link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
    <link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
    <link rel="stylesheet" type="text/css" href="\LMSystem\css\adminBooks.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>          

<div class="right-con" style="width:80%; margin:-45% 0 0 20%;">
    <div class="fetch-user">
        <center class="ce">
            <h5 style="text-align:start; margin:0 0 -1% 5%;"> REFERENCES </h5>
            <table>
                <?php

                    session_start();
                    include("config.php");

                    echo   "<tr>
                            <th>Book ID</th><br>
                            <th>Book Name</th>
                            <th>Book Author</th>
                            <th>Book Category</th>
                            <th>Book Quantity</th>
                            <th>Book Availability</th>
                            </tr>";

                    $sql = mysqli_query($link, "SELECT * FROM books WHERE bookCategory = 'References'");
                            while($res=mysqli_fetch_array($sql)){
                            echo "<td>$res[bookID]</td>";
                            echo "<td>$res[bookName]</td>";
                            echo "<td>$res[bookAuthor]</td>";
                            echo "<td>$res[bookCategory]</td>";
                            echo "<td>$res[bookQuantity]</td>";
                            echo "<td>$res[bookAvailability]</td>"; 
                            echo "</tr>";
                            }
                        ?>
            </table>
        </center>
    </div>
    <div class="fetch-user">
        <center class="ce">
            <h5 style="text-align:start; margin:0 0 -1% 5%;"> COMPUTER BOOKS </h5>
            <table>
                <?php

                    session_start();
                    include("config.php");

                    echo   "<tr>
                            <th>Book ID</th><br>
                            <th>Book Name</th>
                            <th>Book Author</th>
                            <th>Book Category</th>
                            <th>Book Quantity</th>
                            <th>Book Availability</th>
                            </tr>";

                    $sql = mysqli_query($link, "SELECT * FROM books WHERE bookCategory = 'Computer'");
                            while($res=mysqli_fetch_array($sql)){
                            echo "<td>$res[bookID]</td>";
                            echo "<td>$res[bookName]</td>";
                            echo "<td>$res[bookAuthor]</td>";
                            echo "<td>$res[bookCategory]</td>";
                            echo "<td>$res[bookQuantity]</td>";
                            echo "<td>$res[bookAvailability]</td>";
                            echo "</tr>";
                            }
                        ?>
            </table>
        </center>
    </div>
    <div class="fetch-user">
        <center class="ce">
            <h5 style="text-align:start; margin:0 0 -1% 5%;"> DICTIONARIES </h5>
            <table>
                <?php

                    session_start();
                    include("config.php");

                    echo   "<tr>
                            <th>Book ID</th><br>
                            <th>Book Name</th>
                            <th>Book Author</th>
                            <th>Book Category</th>
                            <th>Book Quantity</th>
                            <th>Book Availability</th>
                            </tr>";

                    $sql = mysqli_query($link, "SELECT * FROM books WHERE bookCategory = 'Dictionaries'");
                            while($res=mysqli_fetch_array($sql)){
                            echo "<td>$res[bookID]</td>";
                            echo "<td>$res[bookName]</td>";
                            echo "<td>$res[bookAuthor]</td>";
                            echo "<td>$res[bookCategory]</td>";
                            echo "<td>$res[bookQuantity]</td>";
                            echo "<td>$res[bookAvailability]</td>";
                            
                            echo "</tr>";
                            }
                        ?>
            </table>
        </center>
    </div>
    <div class="fetch-user">
        <center class="ce">
            <h5 style="text-align:start; margin:0 0 -1% 5%;"> MARITIME BOOKS </h5>
            <table>
                <?php

                    session_start();
                    include("config.php");

                    echo   "<tr>
                            <th>Book ID</th><br>
                            <th>Book Name</th>
                            <th>Book Author</th>
                            <th>Book Category</th>
                            <th>Book Quantity</th>
                            <th>Book Availability</th>
                            </tr>";

                    $sql = mysqli_query($link, "SELECT * FROM books WHERE bookCategory = 'Maritime'");
                            while($res=mysqli_fetch_array($sql)){
                            echo "<td>$res[bookID]</td>";
                            echo "<td>$res[bookName]</td>";
                            echo "<td>$res[bookAuthor]</td>";
                            echo "<td>$res[bookCategory]</td>";
                            echo "<td>$res[bookQuantity]</td>";
                            echo "<td>$res[bookAvailability]</td>";
                            
                            echo "</tr>";
                            }
                        ?>
            </table>
        </center>
    </div>
</div>
</body>
<html>