<?php
session_start();
include("config.php");

$id = $_GET['id'];
$sql = mysqli_query($link, "SELECT * FROM student WHERE sID ='$id'");
$pdata = mysqli_fetch_array($sql);

if (ISSET($_POST['update'])){

    $name=$_POST['dash_name'];
    $year=$_POST['dash_username'];
    $course=$_POST['dash_logs'];


    
      mysqli_query($link,"UPDATE student SET sName = '$name', 
      sYear = '$year', sCourse = '$course' WHERE sID = '$id'");

      echo "<script>
        alert('STUDENT INFORMATION HAS BEEN UPDATED!');
        </script>";
        echo "<script>
          location.href='dashboard_student.php';
          </script>";
}
if (ISSET($_POST['Cancel'])){

    echo "<script>
      location.href='dashboard_student.php';
      </script>";

}

?>

<!DOCTYPE html>
<head>
    <title>Update</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\user_updates.css">
</head>
<html>

<div class="wrap-con">
        <center>
        <h1> UPDATE </h1>
        <div class="container" style="height:350px;">
            <form action="" method="POST">
            <i class="fa fa-user-circle icon" aria-hidd en="true"></i>
            <div class="inputs">
            <div class="text">

            </div>  
            <div class="user">
                <div id="user">
                    <div class="flex-con1">
                        <h4> Name: </h4>
                        <input type="text" name="dash_name" value=" <?php echo $pdata['sName']; ?>" >
                    </div>      
                </div> 
            </div>
            <div class="pass">
                <div id="username"> 
                    <div class="flex-con">
                        <h4> Year: </h4>
                        <input type="text" name="dash_username" class="input1" style="margin-left:22%;" value="<?php echo $pdata ['sYear']; ?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4> Course: </h4> 
                    <input type="text" name="dash_logs" class="input4" style="margin-left:16%;" value="<?php echo $pdata ['sCourse'] ?>">
                    </div>
                </div> 
            </div>
            <div class="button-con">    
                    <div style="margin-top:1%;">
                    <input type="submit" name="update" class="update" value="Update">
                    <input type="submit" name="Cancel" class="update" value="Cancel">
                    </div>
            </div>
            </div>
            </div>
            </form>
        </div>  
</center>    
        </div>

</body>
</html>