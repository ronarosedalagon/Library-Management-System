<?php
session_start();
include("config.php");

$id = $_GET['id'];
$sql = mysqli_query($link, "SELECT * FROM student WHERE sID ='$id'");
$pdata = mysqli_fetch_array($sql);

if (ISSET($_POST['Delete'])){

    $name=$_POST['dash_name'];
    $year=$_POST['dash_username'];
    $course=$_POST['dash_logs'];


    
    mysqli_query($link,"DELETE FROM student WHERE sID = '$id'");

    echo "<script>
      alert('STUDENT INFORMATION HAS BEEN DELETED!');
      </script>";
      echo "<script>
        location.href='dashboard_student.php';
        </script>";


}
if (ISSET($_POST['Cancel'])){

    echo "<script>
      location.href='dashboard_student.php';
      </script>";

}

?>

<!DOCTYPE html>
<head>
    <title>Delete</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\user_updates.css">
</head>
<html>

<div class="wrap-con">
        <center>
        <h1> DELETE </h1>
        <div class="container" style="height:400px;">
            <form action="" method="POST">
            <i class="fa fa-user-circle icon" aria-hidd en="true"></i>
            <div class="inputs">
            <div class="text">

            </div>  
            <div class="user">
                <div id="user">
                    <div class="flex-con1">
                        <h4> Name: </h4>
                        <input type="text" name="dash_name" value=" <?php echo $pdata['sName']; ?>" >
                    </div>      
                </div> 
            </div>
            <div class="pass">
                <div id="username"> 
                    <div class="flex-con">
                        <h4> Username: </h4>
                        <input type="text" name="dash_username" class="input1" value="<?php echo $pdata ['sYear']; ?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4> Logs: </h4> 
                    <input type="text" name="dash_logs" class="input4" value="<?php echo $pdata ['sCourse'] ?>">
                    </div>
                </div> 
            </div>
            <div class="button-con">
                    <h4 style="font-family:arial; width:70%;"> Are you sure you want to delete <?php echo $pdata['sName']; ?> ? </h4> 
                    <div style="margin-top:-5%;">
                        <input type="submit" name="Delete" class="update" value="Confirm">
                        <input type="submit" name="Cancel" class="update" value="Cancel">
                    </div>
            </div>
            </div>
            </form>
        </div>  
</center>    
        </div>

</body>
</html>