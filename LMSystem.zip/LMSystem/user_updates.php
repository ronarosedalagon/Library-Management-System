<?php
session_start();
include("config.php");

$id = $_GET['id'];
$sql = mysqli_query($link, "SELECT * FROM user WHERE uID ='$id'");
$pdata = mysqli_fetch_array($sql);

if (ISSET($_POST['update'])){

    $name=$_POST['dash_name'];
    $username=$_POST['dash_username'];
    $password= sha1($_POST['dash_password']);
    $status=$_POST['dash_status'];  
    $logs=$_POST['dash_logs'];


    
      mysqli_query($link,"UPDATE user SET uName = '$name', 
      uUsername = '$username', uPass = '$password', uStatus = '$status', 
      uLogs = '$logs' WHERE uID = '$id'");

      echo "<script>
        alert('DESKTOP INFORMATION HAS BEEN UPDATED!');
        </script>";
        echo "<script>
          location.href='dashboard_user.php';
          </script>";


}

?>

<!DOCTYPE html>
<head>
    <title>Update</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\user_updates.css">
</head>
<html>

<div class="wrap-con">
        <center>
        <h1> UPDATE </h1>
        <div class="container">
            <form action="" method="POST">
            <i class="fa fa-user-circle icon" aria-hidd en="true"></i>
            <div class="inputs">
            <div class="text">

            </div>  
            <div class="user">
                <div id="user">
                    <div class="flex-con1">
                        <h4> Name: </h4>
                        <input type="text" name="dash_name" value=" <?php echo $pdata['uName']; ?>" >
                    </div>      
                </div> 
            </div>
            <div class="pass">
                <div id="username"> 
                    <div class="flex-con">
                        <h4> Username: </h4>
                        <input type="text" name="dash_username" class="input1" value="<?php echo $pdata ['uUsername']; ?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                    <div class="flex-con">
                        <h4> Password: </h4> 
                    <input type="text" name="dash_password" class="input2" value="<?php echo $pdata ['uPass']; ?>" >
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                    <div class="flex-con">
                        <h4> Status: </h4> 
                    <input type="text" name="dash_status" class="input3" value="<?php echo $pdata ['uStatus'] ?>" >
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4> Logs: </h4> 
                    <input type="text" name="dash_logs" class="input4" value="<?php echo $pdata ['uLogs'] ?>">
                    </div>
                </div> 
            </div>
            <div class="button-con">    
                    <input type="submit" name="update" class="update">
            </div>
            </div>
            </form>
        </div>  
</center>    
        </div>

</body>
</html>