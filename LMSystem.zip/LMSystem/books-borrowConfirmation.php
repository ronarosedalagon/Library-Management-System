
<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>
<?php 

$id = $_POST['studentID'];
$sql = mysqli_query($link, "SELECT * FROM student WHERE sID ='$id'");
$pdata = mysqli_fetch_array($sql);

if (ISSET($_POST['submit'])){

$id_input=$_POST['ID'];
$id = $id_input;
$sql = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$id'");
$pdata = mysqli_fetch_array($sql);

}


else if (ISSET($_POST['bookBorrow'])){
        
        $id_input=$_POST['ID'];
        $sql = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$id_input'");
        $pdata = mysqli_fetch_array($sql);

    $availability_input=$_POST['book_availability']-1; 
      mysqli_query($link,"UPDATE books SET bookAvailability = '$availability_input' WHERE bookID = '$id_input'");


      echo "<script>
        alert('BOOKS HAS BEEN SUCCESFULLY BORROWED!');
        </script>";
        echo "<script>
          location.href='books-list.php';
          </script>";


}

?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

<div class="right-con" style="width:100%; margin:-43% 0 0 27%;">
 <!-- this is for the student search -->
 <div class="col1">
 <form action="" method="POST" style="margin:0 0 0 15%;">
           
           <div class="inputs">
           <div class="text">
            
           <div class="user">
               <div id="user" style="display:flex;">
                       <h7 style="margin-top:2%;">Student ID: <h6>
                       <input type="text" name="studentID" style="margin:-12% 0 0 45%; height:40px;width:90%;" value="<?php echo $pdatas['sID'];?>">
                </div>
           <div class="user">
                <div id="user">
                    <div class="flex-con">
                        <h7> Name: </h7>
                        <input type="text" name="dash_name" style="margin:1% 0 0 5%;height:40px;width:15%;" value=" <?php echo $pdata['sName']; ?>" >
                    </div>      
                </div> 
            </div>
            <div class="pass">
                <div id="username"> 
                    <div class="flex-con">
                        <h7> Year: </h7>
                        <input type="text" name="dash_username" class="input1" style="margin:1% 0 0 5.6%; height:40px;width:15%;" value="<?php echo $pdata ['sYear']; ?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h7> Course: </h7> 
                    <input type="text" name="dash_logs" class="input4" style="margin:1% 0 0 4.4%; height:40px;width:15%;" value="<?php echo $pdata ['sCourse'] ?>">
                    </div>
                </div> 
            </div>
           </div>
           </div>
           </form>  
</div>
<div class="col2">
<center>
            <form action="" method="POST" style="margin:0 0 0 10%;">
           
            <div class="inputs">
            <div class="text">
             
            <div class="user">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book ID <h6>
                        <input type="text" name="ID" style="margin-right:-75%;" value="<?php echo $pdata['bookID'];?>">

            </div>
            <div class="button-con" style="margin:-5% 0 0 10%; display:absolute;">    
                    <input type="submit" name="submit" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Search">
                </div>
            </div>  



            <div class="user" style="margin-top:2%;">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Book Name : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
                        <span> <?php echo $pdata['bookName']; ?> </span></h6>
                        
            </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Book Author : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        <span><?php echo $pdata['bookAuthor']; ?></span> </h6> 
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Book Category : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        <span><?php echo $pdata['bookCategory']; ?></span> </h6>
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Book Quantity : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        <span><?php echo $pdata['bookQuantity']; ?></span> </h6>
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Book Availability : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        <span><?php echo $pdata['bookAvailability']; ?></span> </h6>
                </div> 
            </div>
            </div>
            <div class="button-con" style="margin:-1% 0 0 10%;">    
                    <input type="submit" name="bookBorrow" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Borrow">
            </div>
            </div>
            </form>  
</div>
</div>
<script type="text/javascript" src='\LMSystem\js\searchMyTable.js'> </script>
</body>
</html>