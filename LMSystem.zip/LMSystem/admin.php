<?php include_once 'navigation.php'; ?>


<?php
    if (isset($_POST['logout']))
    {
        $sql = "UPDATE user SET uLogs = 'logout'";
        mysqli_query($link,$sql);
        session_destroy();
        header('location:\LMSystem\index.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Admin Dashboard</title>
        <meta charset="utf-8">
        
        <link rel="stylesheet" type="text/css" href="\LMSystem\adminDash.css">
        
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
            
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
            <script>
                function startTime() {
                var today = new Date();
                var h = today.getHours();
                var m = today.getMinutes();
                var s = today.getSeconds();
                m = checkTime(m);
                s = checkTime(s);
                document.getElementById('txt').innerHTML =
                h + ":" + m + ":" + s;
                var t = setTimeout(startTime, 500);
                }
                function checkTime(i) {
                if (i < 10) {i = "0" + i};  
                return i;
                }
            </script>
    </head>

    <body>
        <div class="container-fluid col-12">
            <div class="row gallery" style="margin-top:-20%;">
                <div class="col-sm-3">
                        <a href="\LMSystem\dashboard_user.php"><img src="\LMSystem\images\admin-admin.png" class="img-fluid" alt="Responsive image" id="gallery-img"></a>
                        <div class="details">Admin</div>
                </div>
                <div class="col-sm-3">
                        <a href="\LMSystem\books-list.php"><img src="\LMSystem\images\book-books.png" class="img-fluid" alt="Responsive image" id="gallery-img"></a>
                        <div class="details">Books</div>
                </div>
                <div class="col-sm-3">
                        <a href="\LMSystem\dashboard_student .php"><img src="\LMSystem\images\user-user1.png" class="img-fluid" alt="Responsive image" id="gallery-img"></a>
                        <div class="details">User</div>
                </div>
                <div class="col-sm-3">
                    <form method="POST">
                        <button class="btn" name="logout" style="background-color:white; border:none;">
                        <img src="\LMSystem\images\logout-logout.png" class="img-fluid" alt="Responsive image" id="gallery-img">
                        </button>
                    </form>
                    <div class="details" style="margin-top:2%;">Logout</div>
                </div>
            </div>
        </div>
    </body>
</html>