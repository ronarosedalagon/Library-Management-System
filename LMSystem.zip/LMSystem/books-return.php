<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>
<?php 
?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="">
    <div class="right-con" style="width:80%; margin:-41% 0 0 20%;font-family:arial;font-size:14px;">
		<div class="fetch-user">
		<center class="ce">
            <h5 style="text-align:start; margin:0 0 -1% 5%;"> NOT YET RETURNED </h5>
				<table>
                     
                    <?php
						session_start();
						include("config.php");

                         echo   "<tr>
                                  <th>Student ID</th><br>
		                          <th>Student Name</th><br>
		                          <th>Year Level</th>
		                          <th>Course Taken</th>
                                  <th>Book Title</th>
                                  <th>Book ID</th>
                                  <th>Date Borrowed</th>
                                  <th>Date Returned</th>
                                  <th>Action</th>
		                		</tr>";

		                $sql = mysqli_query($link, "SELECT * FROM borrower WHERE studentDateReturned = 'NOT YET RETURNED'");
                            while($res=mysqli_fetch_array($sql))
                         {
		                          echo "<td>$res[studentID]</td>";
		                          echo "<td>$res[studentName]</td>";
		                          echo "<td>$res[studentYear]</td>";
                                  echo "<td>$res[studentCourse]</td>";
                                  echo "<td>$res[studentBookBorrow]</td>";
                                  echo "<td>$res[studentBookID]</td>";
                                  echo "<td>$res[studentDateBorrow]</td>";
                                  echo "<td>$res[studentDateReturned]</td>";

                                  echo "<td>&nbsp<button style='border: 1px solid red;background-color:#f2f2f2;font-family: arial;'><a href='books-returnUpdate.php?referenceID=$res[referenceID]' 
		                          style='color:black;text-decoration: none;' \> Return </a></button></td>";
		                          echo "</tr>";
                         }                                  
		                    ?>
                </table>
        	</center>
        </div>
        <div class="fetch-user">
			<center class="ce">
            <h5 style="text-align:start; margin:0 0 -1% 5%;"> TRANSACTIONS </h5>
				<table>

					 <?php
						session_start();
						include("config.php");

                         echo   "<tr>
                                  <th>Student ID</th><br>
		                          <th>Student Name</th><br>
		                          <th>Year Level</th>
		                          <th>Course Taken</th>
                                  <th>Book Title</th>
                                  <th>Date Borrowed</th>
                                  <th>Date Returned</th>
		                		</tr>";

		                $sql = mysqli_query($link, "SELECT * FROM borrower");
                            while($res=mysqli_fetch_array($sql))
                         {
		                          echo "<td>$res[studentID]</td>";
		                          echo "<td>$res[studentName]</td>";
		                          echo "<td>$res[studentYear]</td>";
                                  echo "<td>$res[studentCourse]</td>";
                                  echo "<td>$res[studentBookBorrow]</td>";
                                  echo "<td>$res[studentDateBorrow]</td>";
                                  echo "<td>$res[studentDateReturned]</td>";

                                  echo "<td>&nbsp<button style='background-color:#ffff; border:none;font-family: arial;'><a href='books-returnUpdate.php?referenceID=$res[referenceID]' 
		                          style='color:black;text-decoration: none;' \>  </a></button></td>";
		                          echo "</tr>";
                         }                                  
		                    ?>
                </table>
        	</center>

            </div>
    </div>
</body>
</html>