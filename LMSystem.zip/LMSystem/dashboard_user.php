<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php 

if(isset($_POST['dash_submit']))
{
        $id="0";
		$name_input=$_POST['dash_name'];
		$username_input=$_POST['dash_user'];
		$password_input=sha1($_POST['dash_pass']);
		$status_input=$_POST['dash_status'];
		$logss= 'logout';

		$sql = "INSERT INTO user (uID,uName,uUsername,uPass,uStatus,uLogs)
        VALUES('$id','$name_input','$username_input','$password_input','$status_input','$logss')";
        mysqli_query($link,$sql) or die (mysqli_error());
            

           
                            echo '<script type="text/javascript">';
							echo 'alert("Successful Added! \n WELCOME ");';
							echo '</script>';

}


?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="">
<center>
            <form action="" method="POST" style="margin-top:-20%;">
           
            <div class="inputs">
            <div class="text">
                
            </div>  
            <div class="user">
                <div id="user">
                        <input type="text1" name="dash_name" required value="" placeholder="Enter Your Name">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_user" required value="" placeholder="Username">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="password" name="dash_pass" required value="" placeholder="Password">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_status" required value="" placeholder="Status">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_logs" required value="" placeholder="Logs">
                </div> 
            </div>
            <div class="button-con">    
                    <input type="submit" name="dash_submit" class="bttn">
            </div>
            </div>
            </form>  
</center>    

			<div class="fetch-user">
			<center class="ce">
				<table>
					 <?php

						session_start();
						include("config.php");

		                 echo   "<tr>
		                          <th>Fullname</th><br>
		                          <th>Username</th>
		                          <th>Password</th>
		                          <th>Status</th>
		                          <th colspan='2'>Action</th>
		                		</tr>";

		                 $sql = mysqli_query($link, "SELECT * FROM user ");
		                          while($res=mysqli_fetch_array($sql)){
		                          echo "<td>$res[uName]</td>";
		                          echo "<td>$res[uUsername]</td>";
		                          echo "<td>$res[uPass]</td>";
		                          echo "<td>$res[uStatus]</td>";

		                          echo "<td>&nbsp<button style='border: 1px solid red;background-color:#f2f2f2;font-family: arial;'><a href='user_updates.php?id=$res[uID]' 
		                          style='color:black;text-decoration: none;' \> Update </a></button></td>";
		                          echo "<td>&nbsp<button style='border: 1px solid red;background-color:#f2f2f2;font-family: arial;'><a href='user_deletes.php?id=$res[uID]' 
		                          style='color:black;text-decoration: none;' \">Delete</a></button></td>";

		                          echo "</tr>";
		                          }
		                    ?>
            	</table>
        	</center>

			</div>
</body>
</html>