<?php include_once 'navigation.php'; ?>

<!DOCTYPE html>
<head>
    <link rel="stylesheet" type="text/css" href="\LMSystem\css\adminBooks.css">
</head>

<body>
    <div class="left-con">
        <a href="\LMSystem\books-list.php">
            <div class="left-details">
            <img src="\LMSystem\images\book-list.png" style="width:40px;height35px;"><h6>LIST OF BOOKS</h6>
            </div>
        </a>
        <a href="\LMSystem\books-add.php"> 
            <div class="left-details">
            <img src="\LMSystem\images\book-add.png" style="width:40px;height30px;"><h6>ADD BOOKS</h6>
            </div>
        </a>
        <a href="\LMSystem\books-update.php"> 
            <div class="left-details">
            <img src="\LMSystem\images\books-update.png" style="width:40px;height30px;"><h6>UPDATE BOOKS</h6>
            </div> 
        </a>
        <a href="\LMSystem\books-borrow.php"> <div class="left-details">
            <img src="\LMSystem\images\book-books.png" style="width:40px;height30px;"><h6>BORROW BOOKS</h6>
            </div> 
        </a>
        <a href="\LMSystem\books-return.php"> 
            <div class="left-details">
            <img src="\LMSystem\images\books-borrowed.png" style="width:40px;height30px;"><h6>RETURN BOOKS</h6>
            </div> 
        </a>
        <a href="\LMSystem\books-borrowers.php"> 
            <div class="left-details">
            <img src="\LMSystem\images\user-user1.png" style="width:40px;height30px;"><h6>BORROWERS LIST</h6>
            </div> 
        </a>
    </div>

</body>

</html>