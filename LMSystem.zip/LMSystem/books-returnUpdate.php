<?php include_once 'config.php'; ?>

<?php

    $bid = $_POST['bsID'];
    $sqli = mysqli_query($link, "SELECT * FROM books WHERE bookID ='202'");
    $pdatas = mysqli_fetch_array($sqli);

        $sid = $_GET['referenceID'];
        $sql = mysqli_query($link, "SELECT * FROM borrower WHERE referenceID ='$sid'");
        $pdata = mysqli_fetch_array($sql);


    $id_display = $pdata['studentID'];

            if (ISSET($_POST['return'])){

                $sid = $_GET['referenceID'];
                $sql = mysqli_query($link, "SELECT * FROM borrower WHERE referenceID ='$sid'");
                $pdata = mysqli_fetch_array($sql);

                $sid = $_GET['referenceID'];
                $bsBook=$_POST['dateReturned']; 
                
                    mysqli_query($link,"UPDATE borrower SET studentDateReturned = '$bsBook' WHERE referenceID = '$sid'");

                        echo "<script>
                        alert('DATE RETURN RECORDED!');
                        </script>";
                        echo "<script>
                        location.href='books-return.php';
                        </script>";

                // code for return books which adds to the availability count
                    
                $bid = $_POST['bsID'];
                $sqli = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$bid'");
                $pdatas = mysqli_fetch_array($sqli);
                
                $availability_input=$_POST['books-Available'];
                $availability_input++;


                        mysqli_query($link,"UPDATE books SET bookAvailability = '$availability_input' WHERE bookID = '$bid'");

                        echo "<script>
                        alert('BOOKS HAS BEEN SUCCESFULLY RETURNED!');
                        </script>";
                        echo "<script>
                        location.href='books-return.php';
                        </script>";
            }
            else if (ISSET($_POST['cancel'])){

                echo "<script>
                location.href='books-return.php';
                </script>";

            }
?>

<!DOCTYPE html>
<head>
    <title>Return</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\user_updates.css">
</head>
<html>

<div class="wrap-con" style="margin-left:6%;">
        <h1 style="margin-left:33%;text-align:center; font-size:24px;"> RETURN BOOK </h1>
        <div class="container" style="width:25%;margin-left:30%;padding-left:5%;height:80%;">
            <form action="" method="POST">
            <i class="fa fa-user-circle icon" aria-hidd en="true"></i>
            <div class="inputs">
            <div class="text">

            </div>  
            <div class="user">
                <div id="user">
                    <div class="flex-con1">
                        <h4> ID: </h4>
                        <input type="text" name="studentID" style="margin-left:46%;" value="<?=$id_display;?>">
                    </div>      
                </div> 
            </div>
            <div class="pass">
                <div id="username"> 
                    <div class="flex-con">
                        <h4> Name: </h4>
                        <input name="studentName" style="margin-left:30%;" value="<?php echo $pdata['studentName']; ?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                    <div class="flex-con">
                        <h4> Year: </h4> 
                        <input name="studentYear" style="margin-left:35%;" value="<?php echo $pdata['studentYear']; ?>">
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4> Course: </h4> 
                    <input name="studentCourse" style="margin-left:24%;" value="<?php echo $pdata['studentCourse']; ?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4> Book ID: </h4> 
                    <input name="bsID" style="margin-left:31%;" value="<?php echo $pdata ['studentBookID'];?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4 style="margin-top:-2%"> Book Name: </h4> 
                    <input name="Book-name" style="margin:-2% 0 0 24%;" value="<?php echo $pdata ['studentBookBorrow'];?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4 style="margin-top:-1%"> Availability: </h4> 
                    <input name="books-Available" style="margin:-2% 0 0 7%;" value="<?php echo $pdatas['bookAvailability'];?>">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass">
                <div class="flex-con">
                    <h4> Returned On: </h4> 
                    <input name="dateReturned" style="margin-left:15%;" value="<?php echo date("Y-m-d")?>"> </h6>
                    </div>
                </div> 
            </div>

            <div class="button-con" style="margin:-2% 0 0 6%;">    
                    <input type="submit" name="return" class="update" value="RETURN">
                    <input type="submit" name="cancel" class="update" value="CANCEL">
            </div>
            
            </div>
            </form>
        </div>  
        </div>

</body>
</html>