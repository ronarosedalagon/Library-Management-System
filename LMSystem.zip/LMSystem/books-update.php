
<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>
<?php 


if (ISSET($_POST['submit'])){


$id_input=$_POST['ID'];
$id = $id_input;
$sql = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$id'");
$pdata = mysqli_fetch_array($sql);
}


else if (ISSET($_POST['bookUpdate'])){
        
        $id_input=$_POST['ID'];
        $sql = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$id_input'");
        $pdata = mysqli_fetch_array($sql);

    $name_input=$_POST['book_name'];
    $author_input=($_POST['book_author']);
    $category_input=$_POST['book_category'];
    $quantity_input=$_POST['book_quantity'];
    $availability_input=$_POST['book_availability'];


    
      mysqli_query($link,"UPDATE books SET bookName = '$name_input', bookAuthor = '$author_input', bookCategory = '$category_input', 
      bookQuantity = '$quantity_input', bookAvailability = '$availability_input' WHERE bookID = '$id_input'");

      echo "<script>
        alert('BOOKS INFORMATION HAS BEEN UPDATED!');
        </script>";
        echo "<script>
          location.href='books-list.php';
          </script>";


}

?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div class="right-con" style="width:30%; margin:-40% 0 0 40%;">
<center>
            <form action="" method="POST" style="margin:-20%;">
           
            <div class="inputs">
            <div class="text">
             
            <div class="user">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book ID <h6>
                        <input type="text" name="ID" style="margin-right:-100%;" value="<?php echo $pdata['bookID'];?>">

            </div>
            <div class="button-con" style="margin:-10% 0 0 83%; display:absolute;">    
                    <input type="submit" name="submit" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Search">
                </div>
            </div>  



            <div class="user" style="margin-top:2%;">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Name <h6>
                        <input type="text" name="book_name" style="margin-right:-71%;" value="<?php echo $pdata['bookName']; ?>" >
            </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Author <h6> 
                        <input type="text" name="book_author" style="margin-right:-67%;" value="<?php echo $pdata['bookAuthor']; ?>" >
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Category <h6>
                        <input type="text" name="book_category" style="margin-right:-48%;" value="<?php echo $pdata['bookCategory']; ?>" >
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Quantity <h6>
                        <input type="text" name="book_quantity" style="margin-right:-53%;" value="<?php echo $pdata['bookQuantity']; ?>" >
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Availability <h6>
                        <input type="text" name="book_availability"  style="margin-right:-38%;" value="<?php echo $pdata['bookAvailability']; ?>" >
                </div> 
            </div>
            <div class="button-con" style="margin:-1% 0 0 36%;">    
                    <input type="submit" name="bookUpdate" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Update">
            </div>
            </div>
            </form>  

    </div>
</div>
<script type="text/javascript" src='\LMSystem\js\searchMyTable.js'> </script>
</body>
</html>