<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>
<?php 

if(isset($_POST['dash_submit']))
{
        $id_input=$_POST['dash_ID'];
		$name_input=$_POST['dash_name'];
		$author_input=($_POST['dash_author']);
        $category_input=$_POST['dash_category'];
        $quantity_input=$_POST['dash_quantity'];
        $availability_input=$_POST['dash_availability'];

		$sql = "INSERT INTO books (bookID,bookName,bookAuthor,bookCategory,bookQuantity,bookAvailability)
        VALUES('$id_input','$name_input','$author_input','$category_input','$quantity_input','$availability_input')";
        mysqli_query($link,$sql) or die (mysqli_error());
            

           
                            echo '<script type="text/javascript">';
							echo 'alert("Successful Added! \n WELCOME ");';
							echo '</script>';

}


?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div class="right-con" style="width:50%; margin:-40% 0 0 40%;">
<center>
            <form action="" method="POST" style="margin:-20%;">
           
            <div class="inputs">
            <div class="text">
                
            </div>  
            <div class="user">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book ID <h6>
                        <input type="text" name="dash_ID" style="margin-right:-100%;" required value="">
            </div> 
            <div class="user">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Name <h6>
                        <input type="text" name="dash_name" style="margin-right:-71%;" required value="">
            </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Author <h6> 
                        <input type="text" name="dash_author" style="margin-right:-67%;" required value="">
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Category <h6>
                        <input type="text" name="dash_category" style="margin-right:-48%;" required value="">
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Quantity <h6>
                        <input type="text" name="dash_quantity" style="margin-right:-53%;" required value="">
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book Availability <h6>
                        <input type="text" name="dash_availability"  style="margin-right:-38%;" required value="">
                </div> 
            </div>
            <div class="button-con" style="margin:3% 11% 0 0;">    
                    <input type="submit" name="dash_submit" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;">
            </div>
            </div>
            </form>  

    </div>
</div>
</body>
</html>