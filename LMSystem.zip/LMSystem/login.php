<?php include 'config.php'; ?>
<?php 
    if(isset($_POST['submit'])){
        session_start();

    $usernamex = $_POST['user'];
    $passwordx = sha1($_POST['pass']);

    $username = strip_tags(mysqli_real_escape_string($link,trim($usernamex)));
    $password = strip_tags(mysqli_real_escape_string($link,trim($passwordx)));

    $sql = "SELECT * FROM user where uUsername = '".$username."'";
    
	$result = mysqli_query($link,$sql) or die (mysqli_error());
	
 			if(mysqli_num_rows($result)>0){

			while($row=mysqli_fetch_array($result)){

				$password_hash = $row['uPass'];
			    $name_user=$row['uName'];
				if($password == $password_hash){
					
					if( $row['uStatus'] == 'admin' and $row['uLogs'] == 'logout' ) {
						$sql = "UPDATE user SET uLogs = 'login' WHERE uUsername  = '$username'";
                		mysqli_query($link, $sql) or die(mysqli_error());
                			echo '<script type="text/javascript">';
							echo 'alert("Successful Login! \n WELCOME - '.$name_user.'   ");';
							echo 'window.location.href="admin.php"';
							echo '</script>';
						    $_SESSION['name']=$row['uName'];
					}

					else if( $row['uStatus'] == 'admin' and $row['uLogs'] == 'login') {
							echo '<script type="text/javascript">';
							echo 'alert("You are already logged in! '.$name_user.' ");';
        					echo 'window.location.href="login.php"';
							echo '</script>';
					}

				}
				else {
						//$error = "Invalid Password!";
							echo '<script type="text/javascript">';
							echo 'alert("Invalid Password!");';
        					echo 'window.location.href="login.php"';
							echo '</script>';
					}

			}
             	
		}
		else{
			//$error= "Invalid Login Credentials!";
							echo '<script type="text/javascript">';
							echo 'alert("Invalid Credentials! ");';
        					echo 'window.location.href="login.php"';
							echo '</script>';
 
		}
    }
?>

<!DOCTYPE html>
<head>
    <title>Registration</title>
    <link rel="stylesheet" type="text/css" href="\LMSystem\index.css">
    <meta name="viewport" content="width=device-width,initial scale=1,shrink-to-fit=no">

</head>


<body style="margin:0;">

<div class="wrapper">
            <div class="left-con" style="margin-left:6%;">
                    <div class="title">
                        <h1>Admin Login</h1>
                    </div> 
                    <form action="" method="POST">
                        <div class="inputs">
                        <div class="user">
                                <img src="\LMSystem\images\admin.png" id="admin">
                                <input type="text1" name="user" required value="" placeholder="Username">
                        </div>
                        <div class="pass">
                                <img src="\LMSystem\images\password.png" id="password">
                                <input type="password" name="pass" required value="" placeholder="Password">
                        </div>
                        <div class="button-con">    
                            <input type="submit" name="submit" class="button">
                        </div>
                        </div>
                    </form>        
            </div>
            <div class="right-con" style="margin:0;">
                <img src="/LMSystem/images/imagee.jpg" id="image1" style="margin-left:-20%;">
            </div>
</div>

</body>
</html>