<?php include_once 'config.php'; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Admin Dashboard</title>
        <meta charset="utf-8">
        
        <link rel="stylesheet" type="text/css" href="\LMSystem\adminDash.css">
        
			<link rel="stylesheet" href="\LMSystem\css\bootstrap.min.css">
            <link rel="stylesheet" href="\LMSystem\css\font-awesome.min.css">
            
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
            <script>
                function startTime() {
                var today = new Date();
                var h = today.getHours();
                var m = today.getMinutes();
                var s = today.getSeconds();
                m = checkTime(m);
                s = checkTime(s);
                document.getElementById('txt').innerHTML =
                h + ":" + m + ":" + s;
                var t = setTimeout(startTime, 500);
                }
                function checkTime(i) {
                if (i < 10) {i = "0" + i};  
                return i;
                }
            </script>
    </head>

    <body onload="startTime()">
		<div class="overallContainer">
			<div class="container-fluid">
				<div class="row menuWrapper align-items-center">
					<div class="menuR col-1 text-center">
						<img src="\LMSystem\images\admin-icon.png"style="height: 50px;width: 53px; margin-left:65%;">
					</div>

					<div class=" menuC col-8">
						<div class="d-flex align-content-center flex-wrap menuItemsGen">
							<div class="menuItems" style="color: #00D3D1;"> Welcome Admin! &mdash; <?php $names = $SESSION['name']; echo "<span style='text-transform: uppercase'>$names</span>" ?></div>
						</div>
					</div>

					<div class="menuL col-1	">
						<div class="d-flex align-items-center">
                        <a href="\LMSystem\admin.php">
                            <div class="menuLeft p-2">
								<div class="rect-logi d-flex align-items-center justify-content-center">
                                    <div class="logi-sisse" style="color:#00D3D1;"> HOME </div>
								</div>
                            </div>
                        </a>
							<div class="menuLeft p-2">
								<div class="rect-logi d-flex align-items-center justify-content-center">
										<div class="logi-sisse"><span>DATE:</span> <?php echo date("Y-m-d")?><br><span>TIME: </span><span id="txt"></span></div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
        
        <div class="container-fluid col-12">
            <div class="row gallery">
                
            </div>
        </div>
    </body>
</html>