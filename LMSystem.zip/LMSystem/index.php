<?php
include ('config.php');
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Cristal e-College</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1 shrink-to-fit=no">
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		
		
		<link rel="stylesheet" type="text/css" href="\LMSystem\css\main.css">
		<link rel="stylesheet" type="text/css" href="\LMSystem\css\table.css">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	 </head>

	<body>
			<div class="container-fluid">
				<div class="row menuWrapper align-items-center">
					<div class="menuR col-2 text-center">
						<img src="\LMSystem\images\logo.png" id="logo">
					</div>

					<div class=" menuC col-8">
						<div class="d-flex align-content-center flex-wrap menuItemsGen">
							<div class="menuItem p-3"><a href="#home">Home</a></div>
							<div class="menuItem p-3"><a href="#gallerys">Gallery</a></div>
							<div class="menuItem p-3"><a href="#books">Books</a></div>
							<div class="menuItem p-3"><a href="#contact">Connect</a></div>
						</div>
					</div>

					<div class="menuL col-2	">
						<div class="d-flex align-items-center">

							<div class="menuLeft p-2">
								<div class="rect-logi d-flex align-items-center justify-content-center">
										<div class="logi-sisse"><a href="\LMSystem\login.php" style="color: #00D3D1;">Log In</a></div>
								</div>
							</div>

						</div>
					</div>
				</div>

	<div id="home">			
		<div class="desktop-slider-content">
				<div class="section2-sliderContainer">
						<div class="row">
							<div class="col-2 whiteSpace"> </div>
							<div class="col-10 JuunikastRect">
							<div id="myCarousel" class="carousel slide" data-ride="carousel">
									<ol class="carousel-indicators">
										<li data-target="#myCarousel" data-slide-to="0" class="active" id="indicators"></li>
										<li data-target="#myCarousel" data-slide-to="1" id="indicator"></li>
										<li data-target="#myCarousel" data-slide-to="2" id="indicator"></li>
										<li data-target="#myCarousel" data-slide-to="3" id="indicator"></li>
										<li data-target="#myCarousel" data-slide-to="4" id="indicator"></li>
									</ol>
									<div class="carousel-inner">
										  <div class="carousel-item active">
											<div class="carousel-item-1">
													<div class="desktop-carousel-qoute">
															<img src="\LMSystem\images\book-list.png" class="slider-quote">
													</div>
													<div class="desktop-carousel--content-wrapper">
														<div class="desktop-carousel-item--title">
															Cristal e-College <br> Library Management System
														</div>
														<div class="desktop-vertical-line">
														</div>		
														<div class="carousel-item--author">
															Tawala, Panglao, Bohol
														</div>
														<div class="carousel-item--description">
															Developer Student Club (2020)
														</div>
													</div>
											</div>
										 </div>
									<div class="carousel-item">
										<div class="carousel-item-2">
											<div class="desktop-carousel-checkbox">
												<img src="\LMSystem\images\checkbox.png" class="checkbox">
											</div>
												<div class="desktop-carousel-wrapper d-flex">
													<div class="number-item">
														<div class="number">
															01
														</div>
														<div class="text">
															Register<br>
															Account
														</div>
													</div>
						
													<div class="number-item">
														<div class="number">
															02
														</div>
														<div class="text">
															Sign<br> 
															Up
														</div>
													</div>
						
													<div class="number-item">
														<div class="number">
															03
														</div>
														<div class="text">
															Find<br>
															Books
														</div>
													</div>
						
													<div class="number-item">
														<div class="number">
															04
														</div>
														<div class="text">
															Enjoy<br>
															Reading
														</div>
													</div>
												</div>
											</div>
										</div>
									<div class="carousel-item">
											<div class="carousel-item-1">
													<div class="desktop-carousel-qoute">
															<img src="\LMSystem\images\book-list.png" class="slider-quote">
													</div>
													<div class="desktop-carousel--content-wrapper">
														<div class="desktop-carousel-item--title">
															Cristal e-College <br> Library Management System
														</div>
														<div class="desktop-vertical-line">
														</div>		
														<div class="carousel-item--author">
															Tawala, Panglao, Bohol
														</div>
														<div class="carousel-item--description">
															Developer Student Club (2020)
														</div>
													</div>
											</div>
										 </div>
									<div class="carousel-item">
										<div class="carousel-item-2">
											<div class="desktop-carousel-checkbox">
												<img src="\LMSystem\images\checkbox.png" class="checkbox">
											</div>
												<div class="desktop-carousel-wrapper d-flex">
													<div class="number-item">
														<div class="number">
															01
														</div>
														<div class="text">
															Register<br>
															Account
														</div>
													</div>
						
													<div class="number-item">
														<div class="number">
															02
														</div>
														<div class="text">
															Sign<br> 
															Up
														</div>
													</div>
						
													<div class="number-item">
														<div class="number">
															03
														</div>
														<div class="text">
															Find<br>
															Books
														</div>
													</div>
						
													<div class="number-item">
														<div class="number">
															04
														</div>
														<div class="text">
															Enjoy<br>
															Reading
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="carousel-item">
												<div class="carousel-item-1">
													<div class="desktop-carousel-qoute">
															<img src="\LMSystem\images\book-list.png" class="slider-quote">
													</div>
													<div class="desktop-carousel--content-wrapper">
														<div class="desktop-carousel-item--title">
															Cristal e-College <br> Library Management System
														</div>
														<div class="desktop-vertical-line">
														</div>		
														<div class="carousel-item--author">
															Tawala, Panglao, Bohol
														</div>
														<div class="carousel-item--description">
															Developer Student Club (2020)
														</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

					<div class="row float-left searchContainer ">
						<div class="searchGroup col-10">

							<div class="row vaata-jargmisi-kooli-con">
								<div class="vaata-jargmisi-kooli col-11 d-flex align-items-end
								justify-content-end "> </div>
							</div>

							<div class="row">
								<div class=" wrapperSearch col-11 d-md-flex align-content-center
								justify-content-center">
										<div style="color:#33E3FF;font-size:30px;">
											"Greatest Books comes from the Greatest Minds."
										</div>
								</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
			</div>

		<!-- mobile slider interface -->

		<div class="mobile-slider-content">
			<div class="section2-sliderContainer">
					<div class="row">
						<div class="col-12 mobile-JuunikastRect" style="margin-top:30%;">
							<div class="carousel-item-1">
								<div class="mobile-carousel--content-wrapper">
									<div class="mobile-carousel-item--title">
										Cristal e-College <br> Library Management System
									</div>
										<div class="mobile-vertical-line"><div class="mobile-vertical-line"></div>
										</div>		
									<div class="mobile-carousel-item--author">
										Tawala, Panglao, Bohol
									</div>
									<div class="mobile-carousel-item--description">
										Developer Student Club (2020)
									</div>
								</div>
							</div>
						</div>
					</div>
						
					<div class="row float-left searchContainer ">
						<div class="mobile-searchGroup col-12">

							<div class="row">
								<div class="mobile-wrapperSearch col-11 d-md-flex align-content-center
								justify-content-center">
									<div class="d-flex">
										</div>
									</div>			
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
				
			</div>

<!-- start below -->
							<!-- gallery starts here-->
<div id="gallerys">
	<div class="container-fluid col-12">
		<div class="row gallery">
			<div class="col-sm-4">
					<img src="\LMSystem\images\galleryy.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
			<div class="col-sm-4">
					<img src="\LMSystem\images\lib5.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
			<div class="col-sm-4">
					<img src="\LMSystem\images\galleryy1.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
		</div>
		<div class="row gallery1">
			<div class="col-sm-4">
				<img src="\LMSystem\images\lib1.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
			<div class="col-sm-4">
				<img src="\LMSystem\images\lib7.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
			<div class="col-sm-4">
				<img src="\LMSystem\images\lib3.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
		</div>
		<div class="row gallery2">
			<div class="col-sm-4">
				<img src="\LMSystem\images\lib4.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
			<div class="col-sm-4">
				<img src="\LMSystem\images\lib2.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
			<div class="col-sm-4">
				<img src="\LMSystem\images\lib6.jpg" class="img-fluid" alt="Responsive image" id="gallery-img">
			</div>
		</div>  
	</div>
</div>
							  <!-- gallery ends here-->

<div id="books">
	<div class="container books">
		<div class="row">
			<div class="col-sm books-type">
				Dictionaries
			</div>
			<div class="col-sm books-type">
				Computer Books
			</div>
			<div class="col-sm books-type1">
				Maritime Books
			</div>
		</div>
		<div class="row">
			<div class="col-sm books-type">
				Literature Books
			</div>
			<div class="col-sm books-type">
				Accounting Books
			</div>
			<div class="col-sm books-type1">
				Education Books
			</div>
		</div>
		<div class="row">
			<div class="col-sm books-type">
				Fictional Books
			</div>
			<div class="col-sm books-type">
				Scientific Books
			</div>
			<div class="col-sm books-type1">
				History Books
			</div>
		</div>
 	</div>
</div>
<!-- end here here -->
<div id="contact">
	<div class="container">
		<div class="row">
		<div class="col-md-6 col-md-offset-3" style="margin-left:33%;">
			<div class="well well-sm">
			<form class="form-horizontal" action="" method="post" >
			<fieldset>
				<legend style="margin-left:30%;" >Contact us</legend>
		
				<!-- Name input-->
				<div class="form-group">
				<label class="col-md-3 control-label" for="name">Name</label>
				<div class="col-md-9">
					<input id="name" name="name" type="text" placeholder="Your name" class="form-control">
				</div>
				</div>
		
				<!-- Email input-->
				<div class="form-group">
				<label class="col-md-3 control-label" for="email">Your E-mail</label>
				<div class="col-md-9">
					<input id="email" name="email" type="text" placeholder="Your email" class="form-control">
				</div>
				</div>
		
				<!-- Message body -->
				<div class="form-group">
				<label class="col-md-3 control-label" for="message">Your message</label>
				<div class="col-md-9">
					<textarea class="form-control" id="message" name="message" placeholder="Please enter your message here..." rows="5"></textarea>
				</div>
				</div>
		
				<!-- Form actions -->
				<div class="form-group">
				<div class="col-md-12 text-right">
					<button type="submit" class="btn btn-primary btn-lg">Submit</button>
				</div>
				</div>
			</fieldset>
			</form>
			</div>
		</div>
		</div>
	</div>
</div>
</div>
</body>
</html>