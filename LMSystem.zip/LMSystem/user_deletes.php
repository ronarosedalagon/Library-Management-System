<?php
session_start();
include("config.php");

$id = $_GET['id'];
$sql = mysqli_query($link, "SELECT * FROM user WHERE uID ='$id'");
$pdata = mysqli_fetch_array($sql);

if (ISSET($_POST['Delete'])){

    $name=$_POST['dash_name'];
    $username=$_POST['dash_username'];
    $password= sha1($_POST['dash_password']);
    $status=$_POST['dash_status'];
    $logs=$_POST['dash_logs'];


    
      mysqli_query($link,"DELETE FROM user WHERE uID = '$id'");

      echo "<script>
        alert('USER HAS BEEN DELETED!');
        </script>";
        echo "<script>
          location.href='dashboard_user.php';
          </script>";


}
if (ISSET($_POST['Cancel'])){

        echo "<script>
          location.href='dashboard_user.php';
          </script>";


}

?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\user_deletes.css">
</head>
<html>

<div class="wrap-con">
        <center>
        <h1> DELETE </h1>
        <div class="container">
        <form action="" method="POST">
            <div class="inputs">
            <div class="text">

            </div>  
            <div class="user">
                <div id="user">
                    <div class="flex-con1">
                        <h4> Name: </h4>
                        <input type="text" name="dash_name" value=" <?php echo $pdata['uName']; ?> " class="input" >
                    </div> 
                </div>
            </div>
            <div class="pass">
                <div id="username"> 
                    <div class="flex-con">
                        <h4> Username: </h4>
                        <input type="text" name="dash_username"  value="<?php echo $pdata ['uUsername']; ?>"  class="input1">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <div class="flex-con">
                        <h4> Password: </h4>
                        <input type="text" name="dash_password" value="<?php echo $pdata ['uPass']; ?>"  class="input2">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <div class="flex-con">
                        <h4> Status: </h4>
                        <input type="text" name="dash_status" value="<?php echo $pdata ['uStatus'] ?>"  class="input3">
                    </div>
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <div class="flex-con">
                        <h4> Logs: </h4>
                        <input type="text" name="dash_logs" value="<?php echo $pdata ['uLogs'] ?>"  class="input4">
                    </div>
                </div> 
            </div>
            <div class="button-con">
                    <h4 style="font-family:arial; width:70%;"> Are you sure you want to delete <?php echo $pdata['uName']; ?> ? </h4> 
                    <div style="margin-top:-5%;">
                        <input type="submit" name="Delete" class="update" value="Confirm">
                        <input type="submit" name="Cancel" class="update" value="Cancel">
                    </div>
            </div>
            </div>
            </form>
        </div>  
</center>    
        </div>

</body>
</html>