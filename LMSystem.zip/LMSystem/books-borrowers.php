<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>
<?php 


?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="">
<div class="right-con" style="width:80%; margin:-46% 0 0 20%;">
			<div class="fetch-user">
			<center class="ce">
				<table>
					 <?php

						session_start();
						include("config.php");

                         echo   "<tr>
                                  <th>Student ID</th><br>
		                          <th>Student Name</th><br>
		                          <th>Year Level</th>
		                          <th>Course Taken</th>
                                  <th>Book Title</th>
                                  <th>Date Borrowed</th>
                                  <th>Date Returned</th>
		                		</tr>";

		                 $sql = mysqli_query($link, "SELECT * FROM borrower ");
		                          while($res=mysqli_fetch_array($sql)){
		                          echo "<td>$res[studentID]</td>";
		                          echo "<td>$res[studentName]</td>";
		                          echo "<td>$res[studentYear]</td>";
                                  echo "<td>$res[studentCourse]</td>";
                                  echo "<td>$res[studentBookBorrow]</td>";
                                  echo "<td>$res[studentDateBorrow]</td>";
                                  echo "<td>$res[studentDateReturned]</td>";

		                          echo "</tr>";
		                          }
		                    ?>
            	</table>
        	</center>

            </div>
    </div>
</body>
</html>