<?php include_once 'config.php'; ?>
<?php include_once 'admin_dashboard.php'; ?>

<?php 

if(isset($_POST['dash_submit']))
{
        $id="0";
		$name_input=$_POST['dash_name'];
		$username_input=$_POST['dash_user'];
		$password_input=sha1($_POST['dash_pass']);
		$status_input=$_POST['dash_status'];
		$logss= 'logout';

		$sql = "INSERT INTO login(id,name,username,password,status,logs)
        VALUES('$id','$name_input','$username_input','$password_input','$status_input','$logss')";
        mysqli_query($link,$sql) or die (mysqli_error());
            

           
                            echo '<script type="text/javascript">';
							echo 'alert("Successful Added! \n WELCOME ");';
							echo 'window.location.href="dashboard_admin.php"';
							echo '</script>';

}


?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="css/dashboard_admin.css">
</head>


<div class="right-con">
    <div class="container">
        <div class="contain">
            <div class="row">
                <i class="fa fa-user-circle icon" aria-hidden="true"></i>
                <h2> Connect </h2>
                <h4>Meet other students on campus interested in developer
                    technologies. All are welcome, including those with
                    diverse backgrounds and different majors. 
                </h4>
            </div>
            <div class="row">
                <i class="fa fa-user-circle icon" aria-hidden="true"></i>
                <h2> Learn </h2>
                <h4>Learn about a wide range of technical topics where new
                    skills are gained through hands-on workshops, in-person
                    training and project building activities
                </h4>
            </div>
            <div class="row">
                <i class="fa fa-user-circle icon" aria-hidden="true"></i>
                <h2> Grow </h2>
                <h4>
                    Apply your new learnings and connections to build great
                    solutions for local problems. Advance your skills, career 
                    and network. Give back to your community by helping others 
                    learn as well.
                </h4>
            </div>
        </div>
        <div class="wrap-con">
        <center>
            <form action="" method="POST">
            <i class="fa fa-user-circle icon" aria-hidden="true"></i>
            <div class="inputs">
            <div class="text">
                
            </div>  
            <div class="user">
                <div id="user">
                        <input type="text1" name="dash_name" required value="" placeholder="Enter Your Name">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_user" required value="" placeholder="Username">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="password" name="dash_pass" required value="" placeholder="Password">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_status" required value="" placeholder="Status">
                </div> 
            </div>
            <div class="pass">
                <div id="pass"> 
                    <input type="text" name="dash_logs" required value="" placeholder="Logs">
                </div> 
            </div>
            <div class="button-con">    
                    <input type="submit" name="dash_submit" class="bttn">
            </div>
            </div>
            </form>  
</center>    
        </div>
    

</div>
</div>
</div>
        </div>
        </center> 
    </div>
</body>
</html>