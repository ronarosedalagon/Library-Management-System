
<?php
    if (isset($_POST['logout']))
    {
        $sql = "UPDATE user SET uLogs = 'logout'";
        mysqli_query($link,$sql);
        session_destroy();
        header('location:\LMSystem\index.php');

    }
    if (empty($_SESSION['uName'])){
    header('location:\LMSystem\index.php');
?>