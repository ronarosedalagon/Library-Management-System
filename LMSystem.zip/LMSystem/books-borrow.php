
<?php include_once 'navigation.php'; ?>
<?php include_once 'config.php'; ?>
<?php include_once 'dashboard_books.php'; ?>
<?php 


if (ISSET($_POST['submit'])){

$id_input=$_POST['ID'];
$sql = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$id_input'");
$pdata = mysqli_fetch_array($sql);

    $student_input=$_POST['studentID'];
    $sqli = mysqli_query($link, "SELECT * FROM student WHERE sID ='$student_input'");
    $pdatas = mysqli_fetch_array($sqli);
}
if (ISSET($_POST['bookBorrow'])){
    
    // code for adding in the borrowers list

    $borrowers_ID=$_POST['studentID'];
    $borrowers_name=$_POST['studentName'];
    $borrowers_year=$_POST['studentYear'];
    $borrowers_course=$_POST['studentCourse'];
    $borrowers_book=$_POST['booksName'];
    $borrowers_bookID=$_POST['ID'];
    $borrowers_dateBorrowed=$_POST['studentBorrowed'];
    $borrowers_dateReturned='NOT YET RETURNED';

    $sql = "INSERT INTO borrower (studentID,studentName,studentYear,studentCourse,studentBookBorrow,studentBookID,studentDateBorrow,studentDateReturned)
        VALUES('$borrowers_ID','$borrowers_name','$borrowers_year','$borrowers_course','$borrowers_book','$borrowers_bookID','$borrowers_dateBorrowed','$borrowers_dateReturned')";
        mysqli_query($link,$sql) or die (mysqli_error());

                echo '<script type="text/javascript">';
				echo 'alert("BORROWING RECORDED!");';
                echo '</script>';
                
    // code for borrow books which subtracts to the availability count
    $id_input=$_POST['ID'];
    $sql = mysqli_query($link, "SELECT * FROM books WHERE bookID ='$id_input'");
    $pdata = mysqli_fetch_array($sql);

        $availability_input=$_POST['booksAvailable'];
        $availability_input--;


            mysqli_query($link,"UPDATE books SET bookAvailability = '$availability_input' WHERE bookID = '$id_input'");

                echo "<script>
                alert('BOOKS HAS BEEN SUCCESFULLY BORROWED!');
                </script>";
                echo "<script>
                location.href='books-borrow.php';
                </script>";
}
else if (ISSET($_POST['Cancel'])){

    echo "<script>
      location.href='books-list.php';
      </script>";

}

?>

<!DOCTYPE html>
<head>
    <title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_user.css">
	<link rel="stylesheet" type="text/css" href="\LMSystem\css\dashboard_adminn.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div class="right-con" style="width:50%;margin:-40% 0 0 32%;">
<center>
            <form action="" method="POST" style="margin:-20%;">

<div class="lft" style="margin-left:48%;">
            <div class="user">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Book ID <h6>
                        <input type="text" name="ID" style="margin-right:-50%;width:80%;" value="<?php echo $pdata['bookID'];?>"placeholder="Search Book ID....">

            </div>
            <div class="button-con" style="margin:-12% 0 0 85%; display:absolute;">    
                    <input type="submit" name="submit" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Search">
                </div>
            </div>  



            <div class="user" style="margin-top:2%;">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Book Name : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
                        <input style="font-size:15px;" name="booksName" value="<?php echo $pdata['bookName']; ?> "></h6>
                        
            </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:1%; font-weight:bold;">Book Author : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        <input style="font-size:15px;" value="<?php echo $pdata['bookAuthor']; ?>"></h6> 
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:1%; font-weight:bold;">Book Category : &nbsp&nbsp&nbsp&nbsp
                        <input style="font-size:15px;" value="<?php echo $pdata['bookCategory']; ?>"> </h6>
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:1%; font-weight:bold;">Book Quantity : &nbsp&nbsp&nbsp&nbsp&nbsp
                        <input style="font-size:15px;" value="<?php echo $pdata['bookQuantity']; ?>"> </h6>
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:1%; font-weight:bold;">Book Availability : &nbsp
                        <input style="font-size:15px;" name="booksAvailable" value="<?php echo $pdata['bookAvailability']; ?>"> </h6>
                </div> 
            </div>
</div>
<div class="rght" style="margin-top:-37%;">

            <div class="user">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%;">Student ID <h6>
                        <input type="text" name="studentID" style="margin-right:-27%;" value="<?php echo $pdatas['sID'];?>" placeholder="Search Student ID....">
            </div>
            <div class="user" style="margin-top:-1%;">
                <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Full Name : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
                        <input name="studentName" value="<?php echo $pdatas['sName']; ?>"> </span></h6>
                        
            </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Yeal Level : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        <input name="studentYear" value="<?php echo $pdatas['sYear']; ?>"></span> </h6> 
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Course Taken : &nbsp&nbsp&nbsp&nbsp
                        <input name="studentCourse" value="<?php echo $pdatas['sCourse']; ?>"></span> </h6>
                </div> 
            </div>
            <div class="pass">
                        <div id="user" style="display:flex;">
                        <h6 style="margin-top:2%; font-weight:bold;">Date Borrowed : &nbsp&nbsp
                        <input name="studentBorrowed" value="<?php echo date("Y-m-d")?>"> </h6> 
                </div> 
            </div>
            <div class="button-con" style="margin:5% 0 0 60%;">    
                    <input type="submit" name="bookBorrow" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Borrow Book">
            </div>
            <div class="button-con" style="margin:-5% 0 0 90%;">    
                    <input type="submit" name="Cancel" class="bttn" style="background-color:#23313a; border:none; color:#00D3D1;" value="Cancel">
            </div>
            
</div>
            </form>  
<script type="text/javascript" src='\LMSystem\js\searchMyTable.js'> </script>
</body>
</html>